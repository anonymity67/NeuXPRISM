#!/usr/bin/env python
"""NeuXPRISM - run the complete model with one command.

    python run_pipeline.py                      # everything, default paths (data/ -> results/)
    python run_pipeline.py --quick              # skip the slow optional parts (stability runs, bootstrap, multi-seed)
    python run_pipeline.py --multi-seed 5       # also repeat Goals B/C/LDF with 5 different reservoirs
    python run_pipeline.py --help
"""
from __future__ import annotations
import argparse, json, time
from dataclasses import asdict
from pathlib import Path

import numpy as np
import pandas as pd

from neuxprism.config import Config, PAPER_REFERENCE
from neuxprism import data as data_mod, goal_a, goal_c, ldf as ldf_mod, risk, evaluation, explain
from neuxprism.encoding import build_feature_matrix, stepforward_density
from neuxprism.pipeline import run_core, headline


def parse():
    c = Config()
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--data", type=Path, default=c.data_path, help="Main_Dataset_Fixed.xlsx")
    ap.add_argument("--markov", type=Path, default=c.markov_path, help="Markov_Spatial_Weights_Corrected.csv")
    ap.add_argument("--derive-markov", action="store_true",
                    help="compute the spatial weights from the dataset instead of reading the CSV (also the fallback if the CSV is missing)")
    ap.add_argument("--out", type=Path, default=c.out_dir, help="results folder")
    ap.add_argument("--seed", type=int, default=c.seed)
    ap.add_argument("--heritage-encoding", choices=["label", "ordinal"], default=c.heritage_encoding,
                    help="label = alphabetical (original notebook); ordinal = New<Low<Medium<High")
    ap.add_argument("--stability-runs", type=int, default=c.stability_runs, help="repeated NeuCube runs for Goal A (0 = skip)")
    ap.add_argument("--n-boot", type=int, default=c.n_boot, help="bootstrap replicates (0 = skip)")
    ap.add_argument("--multi-seed", type=int, default=0, help="repeat Goals B/C/LDF with N extra reservoir seeds")
    ap.add_argument("--no-figures", action="store_true")
    ap.add_argument("--show", action="store_true", help="also display figures on screen")
    ap.add_argument("--quick", action="store_true", help="skip stability runs, bootstrap and multi-seed")
    return ap.parse_args()


def log(msg): print(f"\n=== {msg} ===", flush=True)


def main():
    a = parse()
    cfg = Config(data_path=a.data, markov_path=a.markov, out_dir=a.out, seed=a.seed,
                 heritage_encoding=a.heritage_encoding, stability_runs=a.stability_runs, n_boot=a.n_boot)
    if a.quick:
        cfg.stability_runs, cfg.n_boot = 0, 0
    cfg.out_dir.mkdir(parents=True, exist_ok=True)
    out = cfg.out_dir
    save = lambda df, name, idx=False: (df.to_csv(out / name, index=idx), print(f"  saved {name}"))
    t0 = time.time()

    import matplotlib
    if not a.show:
        matplotlib.use("Agg")

    # ---------------------------------------------------------------- data
    log("1. Data")
    df = data_mod.load_dataset(cfg.data_path, cfg.sheet_name)
    if a.derive_markov or not cfg.markov_path.exists():
        mtab = goal_c.derive_markov_weights(df, cfg)
        cfg.markov_path = out / "Markov_Spatial_Weights_Derived.csv"
        mtab.to_csv(cfg.markov_path, index=False)
        lookup = goal_c.markov_lookup(mtab)
        print(f"[goal C] Markov weights DERIVED from the dataset for {len(lookup)} spaceports -> {cfg.markov_path.name}")
    else:
        lookup = goal_c.load_markov(cfg.markov_path)
        print(f"[goal C] Markov weights for {len(lookup)} spaceports loaded from {cfg.markov_path.name}")

    # ---------------------------------------------------------------- Goals B + C + LDF + R_final
    log("2. Goals B (fuzzy), C (Markov), LDF and R_final")
    res, extra = run_core(df, cfg, lookup)
    fz = extra["fuzzy"]
    print(f"  UFMB fleet phase probabilities from corpus: Liftoff={extra['fleet_p'][0]:.4f}, Upper={extra['fleet_p'][1]:.4f}")
    save(res.assign(Datum=res["Datum"].dt.date), "NeuXPRISM_Full_Results.csv")
    h = headline(res, cfg)
    print("  " + json.dumps({k: (round(v, 3) if isinstance(v, float) else v) for k, v in h.items()}, indent=2).replace("\n", "\n  "))

    # ---------------------------------------------------------------- Goal A
    log("3. Goal A: cause diagnosis")
    ga = goal_a.neucube_diagnosis(df, cfg)                                  # original: Causes is an input
    gl = goal_a.neucube_diagnosis(df, cfg, drop_target=True, with_stats=False)   # leakage-free
    nc_tbl = pd.concat([ga["table"], gl["table"]], ignore_index=True).assign(**{"Top-2 (%)": np.nan})
    nc_tbl.loc[nc_tbl["Method"].str.startswith("NeuCube + SVM (rbf)") & nc_tbl["Method"].str.contains("as original"), "Top-2 (%)"] = ga["top2"]
    nc_tbl.loc[nc_tbl["Method"].str.startswith("NeuCube + SVM (rbf)") & nc_tbl["Method"].str.contains("removed"), "Top-2 (%)"] = gl["top2"]
    bayes = goal_a.bayesian_diagnosis(df)
    maj = pd.DataFrame([{"Method": "Majority class (Propulsion)", "Top-1 (%)": ga["majority_pct"], "Top-2 (%)": np.nan}])
    goal_a_tbl = pd.concat([maj, nc_tbl, bayes], ignore_index=True)
    print(goal_a_tbl.round(2).to_string(index=False))
    save(goal_a_tbl, "GoalA_Diagnosis.csv")
    if cfg.stability_runs > 0:
        for tag, dt in (("causes_in_input", False), ("causes_removed", True)):
            stab = goal_a.neucube_stability(df, cfg, drop_target=dt)
            print(f"  NeuCube SVM-rbf stability [{tag}] over {len(stab)} runs: mean {stab.top1_pct.mean():.2f}%  "
                  f"sd {stab.top1_pct.std(ddof=0):.2f}%  min {stab.top1_pct.min():.2f}%  max {stab.top1_pct.max():.2f}%")
            save(stab, f"GoalA_NeuCube_Stability_{tag}.csv")
    sA, sB = ga["stats"], fz["stats"]
    spike_tbl = pd.DataFrame([{"reservoir": "Goal A (with Cost, 10 inputs)", **sA}, {"reservoir": "Goal B (no Cost, 9 inputs)", **sB}])
    print(spike_tbl.round(2).to_string(index=False))
    save(spike_tbl, "Reservoir_Activity_Stats.csv")
    Xc, _ = build_feature_matrix(df, cfg.features_with_cost, cfg.categorical, cfg.heritage_encoding, cfg.heritage_map)
    dens = {"rate_input_density_with_cost_pct": float(Xc.mean() * 100),
            "rate_input_density_no_cost_pct": float(fz["X_nocost"].mean() * 100),
            "reservoir_density_goalA_pct": sA["reservoir_spike_density_pct"],
            "reservoir_density_goalB_pct": sB["reservoir_spike_density_pct"], **stepforward_density(Xc)}
    print("  'spike density' depends on WHICH quantity is meant:"); [print(f"    {k:42s} {v:6.2f}%") for k, v in dens.items()]
    save(pd.DataFrame([dens]), "Encoding_Density_Diagnostics.csv")

    # ---------------------------------------------------------------- risk comparison
    log("4. Baselines, tiers and EL comparison")
    comp_tbl = risk.comparison_table(res); print(comp_tbl.round(2).to_string(index=False)); save(comp_tbl, "EL_Comparison.csv")
    cm, rep, acc = risk.tier_confusion(res, cfg); print(cm.to_string()); print(f"  diagonal agreement: {acc:.1%}")
    save(cm, "Tier_Confusion_Matrix.csv", True); save(rep, "Tier_Classification_Report.csv", True)
    save(evaluation.loocv_el_comparison(res, cfg), "LOOCV_EL_Comparison.csv")
    reg, xgb_imp = evaluation.regression_baselines(df, res, cfg); print(reg.round(2).to_string(index=False))
    save(reg, "Baseline_Comparison_EL.csv"); save(xgb_imp, "XGBoost_Feature_Importance.csv")
    sw = evaluation.space_weather_dependence(df, res, cfg.seed); save(sw, "SpaceWeather_Dependence.csv")

    # ---------------------------------------------------------------- SHAP
    log("5. SHAP (Random-Forest surrogate)")
    shap_frames, shap_r2 = {}, {}
    try:
        import shap  # noqa: F401
        for target in ("R_final", "Composite_Risk_Score"):
            imp, r2, _ = explain.shap_importance(fz["X_nocost"], res[target].to_numpy(), fz["feature_names"], cfg)
            shap_frames[target], shap_r2[target] = imp, r2
            save(imp, f"SHAP_Importance_{target}.csv")
            print(f"  target={target}  surrogate R2={r2:.3f}"); print(imp.round(3).to_string(index=False))
    except ImportError as e:
        print(f"  WARNING: 'shap' could not be imported ({e}). Skipping SHAP and Figure 8; everything else still runs.\n"
              "  (shap needs numba, which can lag behind brand-new Python versions.)")

    # ---------------------------------------------------------------- LDF extras
    log("6. LDF sensitivity and walk-forward tables")
    comp_only = res[["n_prior", "CR", "HI", "FF"]]
    sens = ldf_mod.ldf_sensitivity(res, comp_only, cfg); save(sens, "LDF_Sensitivity.csv")
    for co, ve in cfg.walk_forward_pairs:
        t = ldf_mod.walk_forward_table(res, co, ve)
        if len(t):
            print(f"\n  {co} / {ve}"); print(t.to_string(index=False))
            save(t, f"WalkForward_{co}_{ve}.csv".replace("/", "-").replace(" ", "_"))
        else:
            print(f"  (no records for {co} / {ve} in this dataset)")

    # ---------------------------------------------------------------- bootstrap
    dist = None
    if cfg.n_boot > 0:
        log(f"7. Bootstrap ({cfg.n_boot} replicates)")
        dist, ci = evaluation.bootstrap(res, cfg); print(ci.round(3).to_string(index=False))
        save(dist, "NeuXPRISM_Bootstrap_Distributions.csv"); save(ci, "NeuXPRISM_Bootstrap_CI.csv")

    # ---------------------------------------------------------------- multi-seed
    if a.multi_seed > 0:
        log(f"8. Multi-seed robustness ({a.multi_seed} reservoirs)")
        rows = []
        for k in range(a.multi_seed):
            r_k, _ = run_core(df, cfg, lookup, seed=cfg.seed + 1000 + k)
            st = _["fuzzy"]["stats"]
            rows.append({"seed": cfg.seed + 1000 + k, **headline(r_k, cfg),
                         "active_neurons": st["active_neurons"], "reservoir_density_pct": st["reservoir_spike_density_pct"]})
        ms = pd.DataFrame(rows); save(ms, "MultiSeed_Runs.csv")
        summ = ms.drop(columns="seed").agg(["mean", "std", "min", "max"]).T; print(summ.round(3).to_string()); save(summ, "MultiSeed_Summary.csv", True)

    # ---------------------------------------------------------------- figures
    if not a.no_figures:
        log("9. Figures")
        from neuxprism import figures as F
        paths = [F.fig7_el_comparison(res, cm, acc, out, cfg, a.show),
                 F.fig9_neucube_3d(fz["reservoir"], fz["activity"], res, cfg, out, a.show),
                 F.fig_markov_weights(cfg.markov_path, out, a.show),
                 F.fig_ldf_sensitivity(sens, out, a.show),
                 F.fig_evolution(res, cfg, out, a.show)]
        if "R_final" in shap_frames:
            paths.append(F.fig8_shap(shap_frames["R_final"], shap_r2["R_final"], out, a.show))
        if dist is not None:
            paths.append(F.fig_bootstrap(dist, out, cfg.seed, a.show))
        for p in paths: print(f"  saved {p.name}")

    # ---------------------------------------------------------------- reproducibility report
    log("10. Comparison with the numbers in the paper")
    cur = dict(h)
    bayes_row = bayes.iloc[0]
    cur.update({"goal_a_bayes_top1_pct": bayes_row["Top-1 (%)"], "goal_a_bayes_top2_pct": bayes_row["Top-2 (%)"],
                "goal_a_neucube_top1_pct": ga["top1"], "goal_a_neucube_top2_pct": ga["top2"],
                "goal_a_neucube_leakfree_top1_pct": gl["top1"], "goal_a_neucube_leakfree_top2_pct": gl["top2"],
                "goal_a_majority_pct": ga["majority_pct"],
                "input_spike_density_pct": sA["input_spike_density_pct"], "reservoir_spike_density_pct": sA["reservoir_spike_density_pct"], "active_neurons": sA["active_neurons"],
                "shap_surrogate_r2": shap_r2.get("R_final", np.nan)})
    chk = pd.DataFrame([{"quantity": k, "paper": v, "this_run": cur.get(k, np.nan)} for k, v in PAPER_REFERENCE.items()])
    chk["difference"] = chk["this_run"] - chk["paper"]
    print(chk.round(3).to_string(index=False)); save(chk, "Paper_Reference_Check.csv")

    summary = {"headline": {k: (float(v) if isinstance(v, (np.floating, float)) else v) for k, v in cur.items()},
               "config": {k: str(v) for k, v in asdict(cfg).items() if k not in ("operators",)},
               "runtime_seconds": round(time.time() - t0, 1)}
    (out / "run_summary.json").write_text(json.dumps(summary, indent=2, default=str))
    print(f"\nDone in {time.time() - t0:.0f}s. Everything is in: {out.resolve()}")


if __name__ == "__main__":
    main()
