"""Feature matrices and seeded, vectorised rate (Poisson-style Bernoulli) spike encoding."""
from __future__ import annotations
import numpy as np
import pandas as pd
import torch
from sklearn.preprocessing import LabelEncoder, MinMaxScaler


def build_feature_matrix(df, features, categorical, heritage_encoding="label", heritage_map=None):
    """Median-fill AE, encode categoricals, min-max scale, append normalised Time_Position.

    Returns (X [n, len(features)+1] in [0,1], column names).
    """
    X = df[list(features)].copy()
    if "AE_daily" in X:
        X["AE_daily"] = X["AE_daily"].fillna(X["AE_daily"].median())
    for col in categorical:
        if col == "Heritage Category" and heritage_encoding == "ordinal":
            X[col] = df[col].map(heritage_map)
        else:
            X[col] = LabelEncoder().fit_transform(df[col].astype(str))
    scaled = MinMaxScaler().fit_transform(X)
    days = df["Days_Since_Start"].to_numpy(dtype=float)
    time_pos = days / days.max() if days.max() > 0 else days
    return np.column_stack([scaled, time_pos]), list(features) + ["Time_Position"]


def rate_encode(X, T: int, seed: int) -> torch.Tensor:
    """spikes[i, t, j] = 1 with probability X[i, j]  ->  tensor (n, T, features)."""
    X = torch.as_tensor(X, dtype=torch.float32)
    g = torch.Generator().manual_seed(int(seed))
    return (torch.rand((X.shape[0], T, X.shape[1]), generator=g) < X[:, None, :]).float()


def stepforward_density(X, thresholds=(0.10, 0.05, 0.01)) -> dict:
    """Density of the exploratory NeuCube StepForward encoding (records treated as consecutive time steps).
    Reported only as a diagnostic: the pipeline itself uses rate coding."""
    from neucube.encoder import StepForward
    seq = torch.as_tensor(X, dtype=torch.float32).unsqueeze(0)
    n = seq.shape[1] * seq.shape[2]
    return {f"stepforward_th{t}_density_pct": float(StepForward(threshold=t).encode_dataset(seq).abs().sum() / n * 100)
            for t in thresholds}
