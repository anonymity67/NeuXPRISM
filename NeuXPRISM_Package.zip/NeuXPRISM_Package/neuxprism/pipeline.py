"""Core chain: data -> Goal B (mu) -> Goal C -> fusion -> LDF -> R_final -> tiers -> baselines."""
from __future__ import annotations
import numpy as np
import pandas as pd

from . import goal_b, goal_c, risk
from .ldf import compute_ldf


def run_core(df, cfg, markov_lookup, seed=None):
    """Returns (results DataFrame, extras dict). One call = one full NeuXPRISM evaluation at one seed."""
    fz = goal_b.fuzzy_membership(df, cfg, seed)
    cost = df["Cost (M USD)"].to_numpy(float)

    mu = fz["mu"]
    el_fz = goal_b.el_fuzzy(mu, cost)
    p_mk = goal_c.markov_probability(df, markov_lookup, cfg)
    p_ctx = goal_c.contextual_probability(p_mk, mu)
    el_mk = goal_c.el_markov(p_ctx, cost)

    crs = (el_fz + el_mk) / 2.0                                  # Composite Risk Score (pre-LDF)
    comp = compute_ldf(df, cfg)
    r_final = crs * comp["LDF"].to_numpy()                       # LDF-inclusive final output
    ufmb, fleet_p = risk.ufmb_el(df, cfg)

    res = df[["Company Name", "Detail", "Vehicle", "Datum", "Year", "Spaceport", "Phase", "Causes",
              "Heritage Category", "Orbit Type", "Latitude", "Coast_Km", "Ap_daily", "AE_daily",
              "Cost (M USD)"]].copy()
    res["mu_fuzzy"] = mu
    res["P_markov"] = p_mk
    res["P_contextual"] = p_ctx
    res["EL_fuzzy"] = el_fz
    res["EL_markov"] = el_mk
    res["Composite_Risk_Score"] = crs
    res = pd.concat([res, comp], axis=1)
    res["R_final"] = r_final
    res["Tier"] = risk.assign_tier(r_final, cfg)
    res["Tier_preLDF"] = risk.assign_tier(crs, cfg)
    res["Classical_EL"] = cost
    res["UFMB_EL"] = ufmb
    return res, {"fuzzy": fz, "fleet_p": fleet_p}


def headline(res, cfg) -> dict:
    cl = res["Classical_EL"].mean()
    h = {
        "classical_mean_M": cl,
        "ufmb_mean_M": res["UFMB_EL"].mean(),
        "composite_risk_score_mean_M": res["Composite_Risk_Score"].mean(),
        "r_final_mean_M": res["R_final"].mean(),
        "reduction_classical_to_ufmb_pct": (1 - res["UFMB_EL"].mean() / cl) * 100,
        "reduction_classical_to_r_final_pct": (1 - res["R_final"].mean() / cl) * 100,
        "ldf_neutral": int((res["LDF_Category"] == "Neutral").sum()),
        "ldf_discounted": int((res["LDF_Category"] == "Discounted").sum()),
        "ldf_amplified": int((res["LDF_Category"] == "Amplified").sum()),
        "ldf_min": res["LDF"].min(), "ldf_max": res["LDF"].max(),
        "records_changing_tier_due_to_ldf": int((res["Tier"] != res["Tier_preLDF"]).sum()),
    }
    for t in cfg.tier_labels:
        h[f"tier_{t}"] = int((res["Tier"] == t).sum())
    return h
