"""Load and validate the NeuXPRISM master dataset."""
from __future__ import annotations
import warnings
import pandas as pd

REQUIRED = ["Company Name", "Detail", "Vehicle", "Datum", "Year", "Location", "Latitude", "Longitude",
            "Orbit Type", "Status Mission", "Causes", "Phase", "Cost (M USD)", "Heritage Category",
            "Spaceport", "Failures_at_Site", "Coast_Km", "Ap_daily", "AE_daily"]
SITE_ATTRS = ["Latitude", "Longitude", "Coast_Km", "Failures_at_Site"]


def load_dataset(path, sheet_name="Master_Sheet", verbose=True) -> pd.DataFrame:
    """Return the failure corpus sorted chronologically (stable) with Days_Since_Start.

    Sorting matters: every downstream step (reservoir input, labels, LDF walk-forward) uses
    this one ordering, so features and labels can never go out of alignment.
    """
    df = pd.read_excel(path, sheet_name=sheet_name)
    missing = [c for c in REQUIRED if c not in df.columns]
    if missing:
        raise ValueError(f"Dataset is missing required columns: {missing}")

    df["Datum"] = pd.to_datetime(df["Datum"], dayfirst=True, errors="coerce")
    if df["Datum"].isna().any():
        raise ValueError("Some Datum values could not be parsed as dates.")

    df = df[df["Status Mission"].isin(["Failure", "Partial Failure"])].copy()
    df = df.sort_values("Datum", kind="mergesort").reset_index(drop=True)
    df["Days_Since_Start"] = (df["Datum"] - df["Datum"].min()).dt.days

    _validate(df, verbose)
    return df


def _validate(df: pd.DataFrame, verbose: bool) -> None:
    problems = []
    # 1. every spaceport must have exactly one set of site attributes (catches the old row-scramble bug)
    nun = df.groupby("Spaceport")[SITE_ATTRS].nunique().max(axis=1)
    bad = nun[nun > 1]
    if len(bad):
        problems.append(f"Spaceports with inconsistent site attributes: {list(bad.index)}")
    # 2. rows per spaceport must match Failures_at_Site
    cnt = df.groupby("Spaceport").size()
    fas = df.groupby("Spaceport")["Failures_at_Site"].first()
    mism = cnt[cnt != fas.reindex(cnt.index)]
    if len(mism):
        problems.append(f"Rows per Spaceport != Failures_at_Site for: {list(mism.index)}")
    # 3. soft checks
    if df["AE_daily"].isna().sum() > 5:
        problems.append(f"{df['AE_daily'].isna().sum()} missing AE_daily values (expected about 2)")
    if problems:
        raise ValueError("Dataset validation failed:\n  - " + "\n  - ".join(problems))
    if len(df) != 80:
        warnings.warn(f"Corpus has {len(df)} records (paper uses 80).")
    if verbose:
        print(f"[data] {len(df)} records, {df['Spaceport'].nunique()} spaceports, "
              f"{df['Datum'].min().date()} -> {df['Datum'].max().date()}, "
              f"{int(df['AE_daily'].isna().sum())} missing AE_daily (median-filled)")
