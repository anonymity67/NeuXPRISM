"""Fusion, tiers and the Classical / UFMB / NeuXPRISM comparison."""
from __future__ import annotations
import numpy as np
import pandas as pd
from sklearn.metrics import confusion_matrix, classification_report


def assign_tier(values, cfg):
    v = np.asarray(values, float)
    return np.array(cfg.tier_labels, dtype=object)[np.searchsorted(cfg.tier_edges, v, side="right")]


def assign_cost_tier(cost, cfg):
    v = np.asarray(cost, float)
    return np.array(cfg.tier_labels, dtype=object)[np.searchsorted(cfg.cost_tier_edges, v, side="right")]


def fleet_phase_probabilities(df, cfg):
    """UFMB fleet-average P(phase) taken from the corpus itself (23/80 and 49/80 -> 0.2875 / 0.6125)."""
    return (float((df["Phase"] == cfg.phase_liftoff).mean()), float((df["Phase"] == cfg.phase_upper).mean()))


def ufmb_el(df, cfg):
    pl, pu = fleet_phase_probabilities(df, cfg)
    p = np.where(df["Phase"] == cfg.phase_liftoff, pl, np.where(df["Phase"] == cfg.phase_upper, pu, cfg.p_other_phase))
    return p * df["Cost (M USD)"].to_numpy(float), (pl, pu)


def comparison_table(res: pd.DataFrame) -> pd.DataFrame:
    cl, uf = res["Classical_EL"].mean(), res["UFMB_EL"].mean()
    rows = [("Classical EL (= full cost)", cl), ("UFMB (fleet phase prob x cost)", uf),
            ("NeuXPRISM Composite Risk Score (pre-LDF)", res["Composite_Risk_Score"].mean()),
            ("NeuXPRISM R_final (LDF-inclusive)", res["R_final"].mean())]
    return pd.DataFrame([{"Method": m, "Mean EL ($M)": v, "Reduction vs Classical (%)": (1 - v / cl) * 100,
                          "Difference vs UFMB (%)": (v - uf) / uf * 100} for m, v in rows])


def tier_confusion(res: pd.DataFrame, cfg, score_col="R_final"):
    labels = list(cfg.tier_labels)
    actual = assign_cost_tier(res["Cost (M USD)"], cfg)
    pred = res["Tier"].to_numpy() if score_col == "R_final" else assign_tier(res[score_col], cfg)
    cm = confusion_matrix(actual, pred, labels=labels)
    rep = classification_report(actual, pred, labels=labels, zero_division=0, output_dict=True)
    return pd.DataFrame(cm, index=[f"cost:{l}" for l in labels], columns=[f"risk:{l}" for l in labels]), \
        pd.DataFrame(rep).T, float(np.trace(cm) / cm.sum())
