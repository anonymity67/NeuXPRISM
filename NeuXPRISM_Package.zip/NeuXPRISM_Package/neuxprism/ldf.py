"""Learning Discount Factor - walk-forward, per (Company, Vehicle) pair, from PRIOR failures only.

    CR  = same-cause prior failures / prior failures
    HI  = max((heritage_now - heritage_of_latest_prior) / 3, 0)
    FF  = min(n_prior / 9, 1)
    LDF = clip(1 + beta*CR - alpha*HI - gamma*FF, 0.1, 1.5)       (neutral = 1.0 when no prior failure)
"""
from __future__ import annotations
import numpy as np
import pandas as pd


def ldf_components(df, cfg) -> pd.DataFrame:
    """CR, HI, FF and n_prior for every record (df must be date-sorted)."""
    her = df["Heritage Category"].map(cfg.heritage_map)
    if her.isna().any():
        raise ValueError(f"Unknown heritage categories: {sorted(df.loc[her.isna(), 'Heritage Category'].unique())}")
    rows = []
    for i, r in df.iterrows():
        prior = df[(df["Company Name"] == r["Company Name"]) & (df["Vehicle"] == r["Vehicle"]) &
                   (df["Datum"] < r["Datum"])]
        n = len(prior)
        if n == 0:
            cr = hi = ff = 0.0
        else:
            cr = float((prior["Causes"] == r["Causes"]).sum() / n)
            hi = max((her[i] - her[prior.index[-1]]) / 3.0, 0.0)   # prior is date-ordered -> last = latest
            ff = min(n / cfg.ff_cap, 1.0)
        rows.append((n, cr, hi, ff))
    return pd.DataFrame(rows, columns=["n_prior", "CR", "HI", "FF"], index=df.index)


def ldf_value(comp, alpha, beta, gamma, clip=(0.1, 1.5)):
    return np.clip(1.0 + beta * comp["CR"] - alpha * comp["HI"] - gamma * comp["FF"], *clip)


def compute_ldf(df, cfg) -> pd.DataFrame:
    comp = ldf_components(df, cfg)
    comp["LDF"] = ldf_value(comp, cfg.alpha, cfg.beta, cfg.gamma, cfg.ldf_clip)
    comp["LDF_Category"] = np.where(np.isclose(comp["LDF"], 1.0), "Neutral",
                                    np.where(comp["LDF"] < 1.0, "Discounted", "Amplified"))
    return comp


def walk_forward_table(results: pd.DataFrame, company: str, vehicle: str) -> pd.DataFrame:
    """Per-pair walk-forward table (for Falcon 1 / Kairos / Proton-M style paper tables)."""
    p = results[(results["Company Name"] == company) & (results["Vehicle"] == vehicle)]
    return pd.DataFrame({
        "mission": p["Detail"].str.split("|").str[-1].str.strip(),
        "date": p["Datum"].dt.strftime("%Y-%m"),
        "cause": p["Causes"], "heritage": p["Heritage Category"],
        "n_prior": p["n_prior"], "CR": p["CR"].round(3), "HI": p["HI"].round(3), "FF": p["FF"].round(3),
        "LDF": p["LDF"].round(4), "Composite_Risk_Score": p["Composite_Risk_Score"].round(2),
        "R_final": p["R_final"].round(2), "Tier": p["Tier"]}).reset_index(drop=True)


def ldf_sensitivity(results: pd.DataFrame, comp: pd.DataFrame, cfg, scales=(0.5, 0.75, 1.0, 1.25, 1.5)):
    """One-at-a-time sweep of alpha, beta, gamma plus a full grid; reports mean R_final and tier changes."""
    from .risk import assign_tier
    crs = results["Composite_Risk_Score"].to_numpy()
    cost_mean = results["Cost (M USD)"].mean()
    base_tier = assign_tier(crs * results["LDF"].to_numpy(), cfg)

    def summarise(a, b, g, tag, extra):
        ldf = ldf_value(comp, a, b, g, cfg.ldf_clip).to_numpy()
        r = crs * ldf
        t = assign_tier(r, cfg)
        return {"sweep": tag, **extra, "alpha": a, "beta": b, "gamma": g, "mean_R_final": r.mean(),
                "reduction_vs_classical_pct": (1 - r.mean() / cost_mean) * 100,
                "ldf_min": ldf.min(), "ldf_max": ldf.max(), "records_changing_tier": int((t != base_tier).sum())}

    rows = []
    for name in ("alpha", "beta", "gamma"):
        for s in scales:
            w = {"alpha": cfg.alpha, "beta": cfg.beta, "gamma": cfg.gamma}
            w[name] *= s
            rows.append(summarise(w["alpha"], w["beta"], w["gamma"], f"one-at-a-time: {name}", {"scale": s}))
    grid = [0.0, 0.2, 0.4, 0.6]
    for a in grid:
        for b in grid:
            for g in grid:
                rows.append(summarise(a, b, g, "grid", {"scale": np.nan}))
    return pd.DataFrame(rows)
