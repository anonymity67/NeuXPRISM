"""Single place for every setting, hyper-parameter and paper reference number."""
from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path

PACKAGE_ROOT = Path(__file__).resolve().parent.parent


@dataclass
class Config:
    # ---- paths (relative to the project folder; override on the command line)
    data_path: Path = PACKAGE_ROOT / "data" / "Main_Dataset_Fixed.xlsx"
    sheet_name: str = "Master_Sheet"
    coast_edges_km: tuple = (20.0, 500.0)  # Coastal < 20 km <= Near-Inland < 500 km <= Deep-Inland (Markov weights)
    markov_path: Path = PACKAGE_ROOT / "data" / "Markov_Spatial_Weights_Corrected.csv"
    out_dir: Path = PACKAGE_ROOT / "results"

    # ---- reproducibility
    seed: int = 42                      # master seed (encoder noise + reservoir wiring + STDP)

    # ---- NeuCube reservoir / encoding
    T: int = 100                        # rate-coding time steps per record
    cube_shape: tuple = (10, 10, 10)    # 1000 neurons
    mem_thr: float = 0.1
    refractory_period: int = 5
    desnn: dict = field(default_factory=lambda: dict(alpha=5, mod=0.8, drift_up=0.8, drift_down=0.01))

    # ---- feature sets (order matters: it fixes which input neuron sees which feature)
    features_with_cost: tuple = ("Heritage Category", "Orbit Type", "Cost (M USD)", "Phase",
                                 "Causes", "Latitude", "Coast_Km", "Ap_daily", "AE_daily")
    features_no_cost: tuple = ("Heritage Category", "Orbit Type", "Phase", "Causes",
                               "Latitude", "Coast_Km", "Ap_daily", "AE_daily")
    categorical: tuple = ("Heritage Category", "Orbit Type", "Phase", "Causes")
    # 'label'  = alphabetical LabelEncoder, exactly as in the original notebook (High=0, Low=1, Medium=2, New=3)
    # 'ordinal'= New=0, Low=1, Medium=2, High=3 (semantically correct, changes the numbers)
    heritage_encoding: str = "label"

    # ---- Goal C (Markov)
    phase_liftoff: str = "Liftoff Ascent"
    phase_upper: str = "Upper Stage Burn"
    p_other_phase: float = 0.2          # assumed probability for every other phase (UFMB convention)
    fleet_fallback: tuple = (0.2875, 0.6125)  # used if a spaceport is missing from the Markov file

    # ---- LDF (hyper-parameters, not fitted)
    alpha: float = 0.4                  # heritage-improvement weight
    beta: float = 0.4                   # cause-repetition weight
    gamma: float = 0.2                  # failure-frequency weight
    ff_cap: int = 9                     # FF = min(n_prior / ff_cap, 1)
    ldf_clip: tuple = (0.1, 1.5)
    heritage_map: dict = field(default_factory=lambda: {"New": 0, "Low": 1, "Medium": 2, "High": 3})

    # ---- risk tiers ($M)
    tier_edges: tuple = (10.0, 30.0, 60.0)
    tier_labels: tuple = ("Low", "Medium", "High", "Critical")
    cost_tier_edges: tuple = (20.0, 60.0, 150.0)

    # ---- evaluation
    n_boot: int = 1000
    stability_runs: int = 10            # repeated NeuCube runs for Goal A
    multi_seed: int = 0                 # >0: repeat Goals B/C/LDF with this many reservoir seeds
    rf_surrogate: dict = field(default_factory=lambda: dict(n_estimators=100, random_state=42))
    xgb: dict = field(default_factory=lambda: dict(n_estimators=100, max_depth=3, learning_rate=0.1,
                                                   random_state=42, verbosity=0))

    # ---- evolution figure (operators with >=2 failures)
    operators: tuple = (
        ("ISRO", "GSLV Mk I", "ISRO GSLV Mk I", "#8e44ad"),
        ("ILS", "Proton-M/Briz-M", "ILS Proton-M", "#c0392b"),
        ("SpaceX", "Falcon 1", "SpaceX Falcon 1", "#2980b9"),
        ("Rocket Lab", "Electron/Curie", "Rocket Lab Electron", "#e67e22"),
        ("Firefly Aerospace", "Alpha", "Firefly Alpha", "#16a085"),
        ("Roscosmos", "Proton-M/Briz-M", "Roscosmos Proton-M", "#7f8c8d"),
    )
    walk_forward_pairs: tuple = (("SpaceX", "Falcon 1"), ("Space One", "Kairos"), ("ILS", "Proton-M/Briz-M"))


# Numbers reported in the paper / last verified run. The pipeline prints a side-by-side check;
# a difference is information, not an error (the old run used unseeded randomness and the
# pre-repair dataset).
PAPER_REFERENCE = {
    "classical_mean_M": 42.02,
    "ufmb_mean_M": 18.56,
    "composite_risk_score_mean_M": 18.62,
    "r_final_mean_M": 18.95,
    "reduction_classical_to_r_final_pct": 54.9,
    "reduction_classical_to_ufmb_pct": 55.8,
    "tier_Low": 36, "tier_Medium": 29, "tier_High": 14, "tier_Critical": 1,
    "ldf_neutral": 51, "ldf_discounted": 17, "ldf_amplified": 12,
    "ldf_min": 0.711, "ldf_max": 1.378,
    "goal_a_bayes_top1_pct": 58.75, "goal_a_bayes_top2_pct": 77.50,
    "goal_a_neucube_top1_pct": 55.00, "goal_a_neucube_top2_pct": 75.00,
    "goal_a_majority_pct": 55.00,
    "input_spike_density_pct": 48.1,           # assumed to be input-level density; the paper does not define it
    "active_neurons": 297,
    "shap_surrogate_r2": 0.87,
}
