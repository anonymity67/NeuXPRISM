"""NeuXPRISM: neuromorphic spatio-temporal pre-mission PRA with adaptive expected loss."""
__version__ = "1.0.0"
