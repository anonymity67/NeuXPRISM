"""Thin, seeded wrapper around the KEDRI-AUT NeuCube-Py reservoir."""
from __future__ import annotations
import random
import numpy as np
import torch


def seed_everything(seed: int) -> None:
    """The reservoir's small-world wiring and initial weights are random -> seed before building."""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)


def run_reservoir(X_rate: torch.Tensor, inputs: int, cfg, seed: int):
    """Build a fresh (10x10x10) reservoir, run unsupervised STDP learning, return (reservoir, activity).

    activity has shape (records, T, 1000): the spike raster of every neuron for every record.
    """
    from neucube import Reservoir  # imported lazily so the rest of the package works without it
    seed_everything(seed)
    reservoir = Reservoir(cube_shape=cfg.cube_shape, inputs=inputs)
    activity = reservoir.simulate(X_rate, mem_thr=cfg.mem_thr, refractory_period=cfg.refractory_period,
                                  train=True, verbose=False)
    return reservoir, activity


def activity_stats(X_rate: torch.Tensor, activity: torch.Tensor) -> dict:
    """Two different 'spike density' numbers - keep them apart in the paper:
    input_spike_density_pct     = fraction of 1s in the rate-coded INPUT
    reservoir_spike_density_pct = fraction of (record, step, neuron) cells that fired in the RESERVOIR
    """
    per_neuron = activity.abs().sum(dim=(0, 1))
    return {
        "input_spike_density_pct": float(X_rate.mean() * 100),
        "reservoir_spike_density_pct": float(activity.abs().mean() * 100),
        "active_neurons": int((per_neuron > 0).sum()),
        "total_neurons": int(activity.shape[2]),
        "total_reservoir_spikes": float(activity.abs().sum()),
    }
