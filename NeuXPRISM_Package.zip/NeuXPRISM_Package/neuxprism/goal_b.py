"""Goal B - context-aware fuzzy expected loss from a COST-FREE reservoir."""
from __future__ import annotations
import numpy as np
from .encoding import build_feature_matrix, rate_encode
from .reservoir import run_reservoir, activity_stats


def fuzzy_membership(df, cfg, seed=None):
    """mu_fuzzy = min-max of each record's total reservoir spikes (reservoir never sees Cost).

    Returns dict(mu, spike_totals, reservoir, activity, stats, X_nocost).
    """
    seed = cfg.seed + 1 if seed is None else seed
    X, names = build_feature_matrix(df, cfg.features_no_cost, cfg.categorical,
                                    cfg.heritage_encoding, cfg.heritage_map)
    X_rate = rate_encode(X, cfg.T, seed)
    reservoir, activity = run_reservoir(X_rate, inputs=X.shape[1], cfg=cfg, seed=seed)
    totals = activity.sum(dim=(1, 2)).detach().cpu().numpy().astype(float)
    span = totals.max() - totals.min()
    mu = (totals - totals.min()) / span if span > 0 else np.zeros_like(totals)
    return {"mu": mu, "spike_totals": totals, "reservoir": reservoir, "activity": activity,
            "stats": activity_stats(X_rate, activity), "X_nocost": X, "feature_names": names}


def el_fuzzy(mu, cost):
    return np.asarray(mu) * np.asarray(cost, float)
