"""All paper figures, drawn from computed results (no hard-coded numbers)."""
from __future__ import annotations
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches

TIER_COLORS = {"Low": "#27ae60", "Medium": "#f39c12", "High": "#e74c3c", "Critical": "#8b0000"}


def _save(fig, out_dir, name, show=False, **kw):
    path = Path(out_dir) / name
    fig.savefig(path, dpi=300, bbox_inches="tight", **kw)
    if show:
        plt.show()
    plt.close(fig)
    return path


def _short(detail):
    parts = [p.strip() for p in str(detail).split("|")]
    return " | ".join(x[:16] for x in parts[:2])


def fig7_el_comparison(res, cm, acc, out_dir, cfg, show=False):
    fig, axes = plt.subplots(1, 3, figsize=(20, 7))
    first = res.head(10)
    x, w = np.arange(len(first)), 0.25
    a = axes[0]
    a.bar(x - w, first["Classical_EL"], w, label="Classical EL", color="#95a5a6", alpha=.85)
    a.bar(x, first["UFMB_EL"], w, label="UFMB", color="#f39c12", alpha=.85)
    a.bar(x + w, first["R_final"], w, label="NeuXPRISM R_final", color="#2e5fa3", alpha=.85)
    a.set_xticks(x); a.set_xticklabels([_short(d) for d in first["Detail"]], fontsize=7, rotation=40, ha="right")
    a.set_ylabel("Expected loss (M USD)", fontweight="bold")
    a.set_title("(A) Three-way EL comparison\nFirst 10 records (chronological)", fontweight="bold")
    a.legend(fontsize=8)

    b = axes[1]
    cl, uf, nx = res["Classical_EL"].mean(), res["UFMB_EL"].mean(), res["R_final"].mean()
    bars = b.bar(["Classical EL", "UFMB", "NeuXPRISM\nR_final"], [cl, uf, nx],
                 color=["#95a5a6", "#f39c12", "#2e5fa3"], alpha=.85, width=.5)
    for bar, v in zip(bars, [cl, uf, nx]):
        b.text(bar.get_x() + bar.get_width() / 2, v + .3, f"${v:.2f}M", ha="center", fontweight="bold")
    b.text(1, uf / 2, f"-{(1 - uf / cl) * 100:.1f}%", ha="center", color="white", fontweight="bold")
    b.text(2, nx / 2, f"-{(1 - nx / cl) * 100:.1f}%", ha="center", color="white", fontweight="bold")
    b.set_ylabel("Average expected loss (M USD)", fontweight="bold")
    b.set_title(f"(B) Average EL across {len(res)} records", fontweight="bold")

    c = axes[2]
    labels = list(cfg.tier_labels)
    im = c.imshow(cm.to_numpy(), cmap="Blues")
    c.set_xticks(range(4)); c.set_yticks(range(4))
    c.set_xticklabels(labels); c.set_yticklabels(labels)
    c.set_xlabel("NeuXPRISM R_final tier", fontweight="bold"); c.set_ylabel("Cost-based tier", fontweight="bold")
    c.set_title(f"(C) Tier agreement (diagonal = {acc * 100:.0f}%)", fontweight="bold")
    for i in range(4):
        for j in range(4):
            v = cm.to_numpy()[i, j]
            c.text(j, i, str(v), ha="center", va="center", fontweight="bold",
                   color="white" if v > cm.to_numpy().max() / 2 else "black")
    plt.colorbar(im, ax=c)
    for ax in axes[:2]:
        ax.spines[["top", "right"]].set_visible(False)
    fig.suptitle("Figure 7: Expected-loss quantification and risk-tier validation", fontweight="bold", y=1.02)
    plt.tight_layout()
    return _save(fig, out_dir, "Figure7_EL_Comparison.png", show)


def fig8_shap(imp, r2, out_dir, show=False, title="Figure 8: SHAP drivers of R_final"):
    fig, ax = plt.subplots(figsize=(8, 5))
    d = imp.iloc[::-1]
    ax.barh(d["Feature"], d["mean_abs_SHAP"], color="#2e5fa3")
    ax.set_xlabel("mean |SHAP value| ($M)")
    ax.set_title(f"{title}\n(Random-Forest surrogate R² = {r2:.2f})", fontweight="bold")
    ax.spines[["top", "right"]].set_visible(False)
    plt.tight_layout()
    return _save(fig, out_dir, "Figure8_SHAP_Analysis.png", show)


def fig9_neucube_3d(reservoir, activity, res, cfg, out_dir, show=False):
    pos = reservoir.pos.detach().cpu().numpy()
    act = activity.sum(dim=(0, 1)).detach().cpu().numpy().astype(float)
    span = act.max() - act.min()
    a_norm = (act - act.min()) / span if span > 0 else np.zeros_like(act)
    mask = act > 0
    fig = plt.figure(figsize=(20, 8)); fig.patch.set_facecolor("#0a0f1e")
    ax1 = fig.add_subplot(131, projection="3d"); ax1.set_facecolor("#0a0f1e")
    sc = ax1.scatter(pos[mask, 0], pos[mask, 1], pos[mask, 2], c=a_norm[mask], cmap="hot",
                     s=a_norm[mask] * 100 + 5, alpha=.8, edgecolors="none")
    for f in ("set_xlabel", "set_ylabel", "set_zlabel"):
        getattr(ax1, f)(f[4].upper(), color="white", fontsize=8)
    ax1.tick_params(colors="white", labelsize=6)
    ax1.set_title(f"(A) NeuCube 3D activation\n{mask.sum()} / {len(act)} neurons active", color="white", fontweight="bold")
    cb = plt.colorbar(sc, ax=ax1, shrink=.5); cb.set_label("Activation level", color="white")
    plt.setp(cb.ax.yaxis.get_ticklabels(), color="white")

    ax2 = fig.add_subplot(132); ax2.set_facecolor("#0a0f1e")
    ax2.hist(a_norm[mask], bins=20, color="#f39c12", alpha=.85, edgecolor="white")
    ax2.set_xlabel("Activation level", color="white"); ax2.set_ylabel("Number of neurons", color="white")
    ax2.set_title("(B) Neuron activation distribution", color="white", fontweight="bold")
    ax2.tick_params(colors="white")
    for s in ("bottom", "left"):
        ax2.spines[s].set_color("white")
    ax2.spines[["top", "right"]].set_visible(False)
    ax2.text(.55, .8, f"Active: {mask.sum()}/{len(act)}\n({mask.mean() * 100:.1f}%)", transform=ax2.transAxes, color="white")

    ax3 = fig.add_subplot(133); ax3.set_facecolor("#0a0f1e")
    counts = [int((res["Tier"] == t).sum()) for t in cfg.tier_labels]
    nz = [(t, c) for t, c in zip(cfg.tier_labels, counts) if c > 0]
    _, _, auto = ax3.pie([c for _, c in nz], labels=[t for t, _ in nz], colors=[TIER_COLORS[t] for t, _ in nz],
                         autopct="%1.1f%%", startangle=90, wedgeprops=dict(edgecolor="#0a0f1e", linewidth=2),
                         textprops=dict(color="white"))
    for t in auto:
        t.set_fontweight("bold")
    ax3.set_title(f"(C) NeuXPRISM risk tiers ({len(res)} records)", color="white", fontweight="bold")
    fig.suptitle("Figure 9: NeuCube spatio-temporal activation and risk output", color="white", fontweight="bold", y=1.01)
    plt.tight_layout()
    return _save(fig, out_dir, "Figure9_NeuCube_3D_Actual.png", show, facecolor="#0a0f1e")


def fig_markov_weights(markov_csv, out_dir, show=False):
    mw = pd.read_csv(markov_csv)
    cols = [c for c in ("P_Liftoff_Baseline", "P_Liftoff_Adjusted", "P_Upper_Baseline", "P_Upper_Adjusted") if c in mw]
    mw = mw.sort_values("P_Upper_Adjusted")
    fig, axes = plt.subplots(1, 2, figsize=(14, 7), sharey=True)
    y = np.arange(len(mw))
    for ax, (b, a, t) in zip(axes, [("P_Liftoff_Baseline", "P_Liftoff_Adjusted", "Liftoff Ascent"),
                                    ("P_Upper_Baseline", "P_Upper_Adjusted", "Upper Stage Burn")]):
        if b in mw:
            ax.barh(y + .2, mw[b], .4, color="#bdc3c7", label="Fleet baseline")
        ax.barh(y - .2, mw[a], .4, color="#2e5fa3", label="Spatially adjusted")
        ax.set_title(f"P({t} | spaceport)", fontweight="bold"); ax.legend(fontsize=8)
        ax.spines[["top", "right"]].set_visible(False)
    axes[0].set_yticks(y); axes[0].set_yticklabels(mw["Spaceport"], fontsize=8)
    fig.suptitle("Spatial Markov weights by spaceport", fontweight="bold")
    plt.tight_layout()
    return _save(fig, out_dir, "Figure6_Markov_Weights.png", show)


def fig_ldf_sensitivity(sens, out_dir, show=False):
    one = sens[sens["sweep"].str.startswith("one-at-a-time")]
    fig, axes = plt.subplots(1, 2, figsize=(13, 4.5))
    for name, col in (("alpha", "#8e44ad"), ("beta", "#c0392b"), ("gamma", "#16a085")):
        d = one[one["sweep"].str.endswith(name)]
        axes[0].plot(d["scale"], d["mean_R_final"], marker="o", color=col, label=name)
        axes[1].plot(d["scale"], d["records_changing_tier"], marker="o", color=col, label=name)
    axes[0].set_ylabel("Mean R_final ($M)"); axes[1].set_ylabel("Records changing tier")
    for ax in axes:
        ax.set_xlabel("Weight scale (1.0 = paper value)"); ax.legend(); ax.spines[["top", "right"]].set_visible(False)
    fig.suptitle("LDF weight sensitivity (one-at-a-time)", fontweight="bold")
    plt.tight_layout()
    return _save(fig, out_dir, "Figure11_LDF_Sensitivity.png", show)


def fig_bootstrap(dist, out_dir, seed=42, show=False):
    import seaborn as sns
    configs = [("mean_R_final", "Mean $R_{final}$", r"\${:.2f}M"), ("pct_reduction_vs_classical", "EL reduction", "{:+.1f}%"),
               ("disc_correction_pct", "Discount correction", "{:+.1f}%"), ("ampl_correction_pct", "Amplify correction", "{:+.1f}%"),
               ("pct_diff_vs_ufmb", "$R_{final}$ vs UFMB", "{:+.1f}%")]
    colors = ["#1f77b4", "#2ca02c", "#d62728", "#9467bd", "#e377c2"]
    rng = np.random.default_rng(seed)
    sns.set_theme(style="white")
    fig, axes = plt.subplots(5, 1, figsize=(8, 10), gridspec_kw={"hspace": .7})
    for ax, (col, title, fmt), c in zip(axes, configs, colors):
        data = dist[col].dropna()
        lo, hi, mean = np.percentile(data, 2.5), np.percentile(data, 97.5), data.mean()
        kde = sns.kdeplot(data=data, ax=ax, color=c, linewidth=2, zorder=3)
        xl, yl = kde.lines[-1].get_data()
        m = (xl >= lo) & (xl <= hi)
        ax.fill_between(xl[m], yl[m], color=c, alpha=.3); ax.fill_between(xl[~m], yl[~m], color=c, alpha=.08)
        rain = data.sample(n=min(80, len(data)), random_state=seed)
        off = -max(yl) * .1
        ax.scatter(rain, rng.uniform(off * 1.3, off * .7, len(rain)), color=c, alpha=.4, s=12, linewidths=0)
        ax.axvline(mean, color="black", lw=1.5); ax.axvline(lo, color="black", ls=":", alpha=.5); ax.axvline(hi, color="black", ls=":", alpha=.5)
        if lo < 0 < hi and "%" in fmt:
            ax.axvline(0, color="#d95f02", ls="--", lw=1.2)
        ax.set_title(title, loc="left", fontweight="bold"); ax.get_yaxis().set_visible(False)
        sns.despine(ax=ax, left=True)
        ax.text(1.02, .5, f"Mean: {fmt.format(mean)}\n95% CI: [{fmt.format(lo)}, {fmt.format(hi)}]", transform=ax.transAxes,
                va="center", fontsize=10, fontweight="semibold", bbox=dict(boxstyle="round,pad=.4", fc="#f9f9f9", ec="#e0e0e0"))
    plt.subplots_adjust(right=.75)
    return _save(fig, out_dir, "bootstrap_plot.png", show)


def fig_evolution(res, cfg, out_dir, show=False):
    """Stacked-area LDF coverage per year + operator LDF trajectories (Evolution figure v3)."""
    comp = res.rename(columns={"Company Name": "Company", "LDF_Category": "Category"})
    years = sorted(comp["Year"].unique())
    pct = lambda cat: [(comp[comp["Year"] == y]["Category"] == cat).mean() * 100 for y in years]
    roll = lambda a, w=2: [np.mean(a[max(0, i - w):i + w + 1]) for i in range(len(a))]
    neu, dis, amp = roll(pct("Neutral")), roll(pct("Discounted")), roll(pct("Amplified"))
    total = [int((comp["Year"] == y).sum()) for y in years]
    cat_col = {"Neutral": "#bdc3c7", "Discounted": "#27ae60", "Amplified": "#c0392b"}

    fig = plt.figure(figsize=(20, 13))
    ax = fig.add_axes([.06, .40, .91, .52]); at = fig.add_axes([.06, .06, .91, .28])
    nd = np.array(neu) + np.array(dis)
    ax.fill_between(years, 0, neu, alpha=.75, color=cat_col["Neutral"], label="Neutral (LDF = 1.0): no prior history")
    ax.fill_between(years, neu, nd, alpha=.85, color=cat_col["Discounted"], label="Discounted (LDF < 1.0): operator showed learning")
    ax.fill_between(years, nd, nd + np.array(amp), alpha=.85, color=cat_col["Amplified"], label="Amplified (LDF > 1.0): repeated failure cause")
    ax.plot(years, neu, color="white", lw=.9); ax.plot(years, nd, color="white", lw=.9)

    # operator bands derived from the data (first-last year of each multi-failure pair)
    for k, (co, ve, label, color) in enumerate(cfg.operators):
        sub = comp[(comp["Company"] == co) & (comp["Vehicle"] == ve)]
        if len(sub) < 2:
            continue
        y0, y1 = sub["Year"].min(), sub["Year"].max()
        ax.axvspan(y0 - .3, y1 + .3, alpha=.035, color=color)
        ax.text(y0 + .1, 101.5, label, fontsize=6.8, color=color, rotation=90, ha="left", va="bottom", fontweight="bold",
                bbox=dict(boxstyle="round,pad=.15", fc="white", alpha=.88, ec=color, lw=.8))
    for y, n in zip(years, total):
        if n >= 3:
            ax.text(y, 107, str(n), ha="center", va="bottom", fontsize=7, fontweight="bold", color="#444")
    ax.set_xlim(min(years) - .5, max(years) + .8); ax.set_ylim(0, 118)
    ax.set_yticks([0, 25, 50, 75, 100]); ax.set_yticklabels([f"{v}%" for v in (0, 25, 50, 75, 100)])
    ax.set_ylabel("% of records per year", fontweight="bold")
    ax.set_xticks(years); ax.set_xticklabels([str(y) if y % 2 == 1 else "" for y in years], rotation=45, ha="right")
    ax.spines[["top", "right"]].set_visible(False); ax.grid(axis="y", alpha=.22)
    ax.set_title(f"NeuXPRISM evolving system: LDF coverage across all {len(comp)} records ({min(years)}-{max(years)})\n"
                 "Stacked area: Neutral / Discounted / Amplified per year (5-point rolling mean)  |  numbers above: record count (small yearly counts, read as trend)", fontweight="bold", pad=14)
    ax.legend(loc="upper left", fontsize=7, title="LDF category", bbox_to_anchor=(.01, .81))

    at.set_facecolor("#F8F8F8"); at.axhline(1.0, color="gray", ls="--", alpha=.65)
    at.fill_between([min(years) - 1, max(years) + 1], .68, 1.0, alpha=.07, color="#27ae60")
    at.fill_between([min(years) - 1, max(years) + 1], 1.0, 1.5, alpha=.07, color="#c0392b")
    for co, ve, label, color in cfg.operators:
        sub = comp[(comp["Company"] == co) & (comp["Vehicle"] == ve)].sort_values("Datum")
        if len(sub) < 2:
            continue
        yrs, ldf = sub["Year"].to_numpy(), sub["LDF"].to_numpy()
        for i in range(len(yrs) - 1):          # solid for consecutive flights, faint dashed across long gaps (no data between)
            gap = yrs[i + 1] - yrs[i] > 3
            at.plot(yrs[i:i + 2], ldf[i:i + 2], color=color, lw=1.6 if gap else 2.4, ls=(0, (3, 3)) if gap else "-",
                    alpha=.45 if gap else 1)
        at.scatter(yrs, ldf, s=40, color=color, zorder=4)
        at.plot([], [], color=color, lw=2.4, marker="o", ms=6, label=label)   # clean legend entry
        at.scatter(sub["Year"], sub["LDF"], s=70, c=[cat_col[c] for c in sub["Category"]], edgecolors=color, lw=2, zorder=5)
    at.set_xlim(min(years) - .5, max(years) + .8); at.set_ylim(.67, 1.52)
    at.set_ylabel("LDF value", fontweight="bold"); at.set_xlabel("Year", fontweight="bold")
    at.set_xticks(years); at.set_xticklabels([str(y) if y % 2 == 1 else "" for y in years], rotation=45, ha="right")
    at.spines[["top", "right"]].set_visible(False)
    at.set_title("Operator-level LDF trajectories (multi-failure programmes); dot colour = Neutral / Discounted / Amplified", fontweight="bold")
    at.legend(loc="upper right", fontsize=8.5, ncol=3)
    return _save(fig, out_dir, "NeuXPRISM_Evolution.png", show, facecolor="white")
