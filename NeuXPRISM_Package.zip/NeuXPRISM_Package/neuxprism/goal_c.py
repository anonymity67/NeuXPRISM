"""Goal C - spatial Markov expected loss."""
from __future__ import annotations
import numpy as np
import pandas as pd

NEEDED = ["Spaceport", "P_Liftoff_Adjusted", "P_Upper_Adjusted"]


def derive_markov_weights(df, cfg) -> pd.DataFrame:
    """Rebuild the spatial weights from the failure corpus itself (no external CSV needed).

    Method (this is what the shipped Markov_Spatial_Weights CSV does; it differs from Eq. 4-6 of the draft):
      1. Fleet phase shares  P_L = share of failures in Liftoff Ascent, P_U = share in Upper Stage Burn.
      2. Relative factor of a group g for phase k:  r_k(g) = P(phase k | g) / P(phase k)   (failure counts only).
         Groups: latitude band, and a 3-level coast category (Coastal / Near-Inland / Deep-Inland from Coast_Km).
      3. Site weight  W_k = r_k(lat band) * r_k(coast category)      (latitude and coast treated as independent).
      4. P_adjusted_k = P_k * W_k / (P_L*W_L + P_U*W_U + P_other),   P_other = 1 - P_L - P_U,
         so the three phase probabilities sum to 1.
    Sites sharing a latitude band and coast category therefore share weights (about 8 distinct pairs for 19 sites).
    """
    lo, hi = cfg.coast_edges_km
    d = df.copy()
    d["Coast_Cat"] = np.where(d["Coast_Km"] < lo, "Coastal", np.where(d["Coast_Km"] < hi, "Near-Inland", "Deep-Inland"))
    isL = (d["Phase"] == cfg.phase_liftoff).astype(float)
    isU = (d["Phase"] == cfg.phase_upper).astype(float)
    pl, pu = isL.mean(), isU.mean()
    po = 1.0 - pl - pu

    def factor(key, ind, p):
        return ind.groupby(d[key]).mean() / p

    site = d.groupby("Spaceport")[["Lat_Band", "Coast_Cat"]].first()
    wl = factor("Lat_Band", isL, pl)[site["Lat_Band"]].to_numpy() * factor("Coast_Cat", isL, pl)[site["Coast_Cat"]].to_numpy()
    wu = factor("Lat_Band", isU, pu)[site["Lat_Band"]].to_numpy() * factor("Coast_Cat", isU, pu)[site["Coast_Cat"]].to_numpy()
    k = 1.0 / (pl * wl + pu * wu + po)
    out = site.reset_index()
    out["W_Liftoff"], out["W_UpperStage"] = wl, wu
    out["P_Liftoff_Baseline"], out["P_Upper_Baseline"] = pl, pu
    out["P_Liftoff_Adjusted"], out["P_Upper_Adjusted"] = pl * wl * k, pu * wu * k
    return out


def markov_lookup(table: pd.DataFrame) -> dict:
    return dict(zip(table["Spaceport"], zip(table["P_Liftoff_Adjusted"], table["P_Upper_Adjusted"])))


def load_markov(path) -> dict:
    """{Spaceport: (P_liftoff, P_upper)} from the spatial-weights CSV."""
    try:
        mw = pd.read_csv(path)
    except FileNotFoundError:
        raise FileNotFoundError(
            f"Markov weights file not found: {path}\n"
            "Put 'Markov_Spatial_Weights_Corrected.csv' in the data/ folder or pass --markov <path>.")
    missing = [c for c in NEEDED if c not in mw.columns]
    if missing:
        raise ValueError(f"{path} lacks columns {missing}; found {list(mw.columns)}")
    return dict(zip(mw["Spaceport"], zip(mw["P_Liftoff_Adjusted"], mw["P_Upper_Adjusted"])))


def _phase_prob(phase, pl, pu, cfg):
    if phase == cfg.phase_liftoff:
        return pl
    if phase == cfg.phase_upper:
        return pu
    return cfg.p_other_phase


def markov_probability(df, lookup, cfg):
    """P(phase | site) for each record, using the fleet fallback for unknown spaceports."""
    unknown = sorted(set(df["Spaceport"]) - set(lookup))
    if unknown:
        print(f"[goal C] WARNING: no Markov weights for {unknown}; using fleet fallback {cfg.fleet_fallback}")
    out = []
    for sp, ph in zip(df["Spaceport"], df["Phase"]):
        pl, pu = lookup.get(sp, cfg.fleet_fallback)
        out.append(_phase_prob(ph, pl, pu, cfg))
    return np.array(out, float)


def contextual_probability(p_markov, mu):
    """P(phase | site, context) = (P_markov + mu_fuzzy) / 2"""
    return (np.asarray(p_markov) + np.asarray(mu)) / 2.0


def el_markov(p_ctx, cost):
    return np.asarray(p_ctx) * np.asarray(cost, float)
