"""Baselines, LOOCV EL comparison, bootstrap and space-weather dependence tests."""
from __future__ import annotations
import numpy as np
import pandas as pd
from scipy.stats import spearmanr
from sklearn.feature_selection import mutual_info_regression, mutual_info_classif
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error
from sklearn.model_selection import LeaveOneOut, cross_val_predict
from sklearn.preprocessing import LabelEncoder, MinMaxScaler
from sklearn.utils import resample


def loocv_el_comparison(res, cfg):
    """Classical / UFMB (training-fold phase frequency) / NeuXPRISM, scored against cost as the proxy truth.

    NOTE: because the proxy 'actual' loss is the mission cost, this table measures how far each estimate
    sits below full cost; it is a descriptive comparison, not an out-of-sample accuracy claim.
    """
    cost = res["Cost (M USD)"].to_numpy(float)
    ufmb = []
    for i in range(len(res)):
        train = res.drop(res.index[i])
        ph = res["Phase"].iloc[i]
        if ph in (cfg.phase_liftoff, cfg.phase_upper):
            p = (train["Phase"] == ph).mean()
        else:
            p = cfg.p_other_phase
        ufmb.append(p * cost[i])
    preds = {"Classical EL": cost, "UFMB": np.array(ufmb), "NeuXPRISM": res["R_final"].to_numpy(float)}
    rows = [{"Method": k, "MAE": np.mean(np.abs(v - cost)), "RMSE": np.sqrt(np.mean((v - cost) ** 2)),
             "Avg EL": v.mean()} for k, v in preds.items()]
    return pd.DataFrame(rows)


def regression_baselines(df, res, cfg):
    """Linear Regression and XGBoost (LOOCV) trying to reproduce R_final from the raw inputs (+Cost)."""
    from xgboost import XGBRegressor
    d = df.copy()
    d["Heritage_enc"] = d["Heritage Category"].map(cfg.heritage_map)
    for src, dst in (("Orbit Type", "Orbit_enc"), ("Phase", "Phase_enc"), ("Causes", "Cause_enc")):
        d[dst] = LabelEncoder().fit_transform(d[src])
    d["Datum_enc"] = d["Datum"].map(lambda x: x.toordinal())
    d["AE_filled"] = d["AE_daily"].fillna(d["AE_daily"].median())
    cols = ["Heritage_enc", "Orbit_enc", "Phase_enc", "Cause_enc", "Latitude", "Coast_Km", "Ap_daily",
            "AE_filled", "Datum_enc", "Cost (M USD)"]
    X = MinMaxScaler().fit_transform(d[cols].fillna(d[cols].median()))
    y = res["R_final"].to_numpy(float)
    loo = LeaveOneOut()
    lr = np.clip(cross_val_predict(LinearRegression(), X, y, cv=loo), 0, None)
    xg = np.clip(cross_val_predict(XGBRegressor(**cfg.xgb), X, y, cv=loo), 0, None)
    classical = d["Cost (M USD)"].to_numpy(float)
    ufmb_const = np.full(len(y), res["UFMB_EL"].mean())
    crs = res["Composite_Risk_Score"].to_numpy(float)
    mae = lambda p: mean_absolute_error(y, p)
    rmse = lambda p: float(np.sqrt(mean_squared_error(y, p)))
    table = pd.DataFrame([
        ("Classical EL (full cost)", mae(classical), rmse(classical)),
        ("UFMB (corpus mean)", mae(ufmb_const), rmse(ufmb_const)),
        ("Linear Regression (LOOCV)", mae(lr), rmse(lr)),
        ("XGBoost Regressor (LOOCV)", mae(xg), rmse(xg)),
        ("Composite Risk Score (pre-LDF)", mae(crs), rmse(crs)),
    ], columns=["Method", "MAE ($M)", "RMSE ($M)"])
    fi = XGBRegressor(**cfg.xgb).fit(X, y).feature_importances_
    imp = pd.DataFrame({"Feature": cols, "XGBoost Importance": fi}).sort_values("XGBoost Importance", ascending=False)
    return table, imp


def bootstrap(res, cfg, ufmb_mean=None):
    """Resample the 80 records with replacement (random_state = replicate index, as in the original script)."""
    ufmb_mean = res["UFMB_EL"].mean() if ufmb_mean is None else ufmb_mean
    out = {k: [] for k in ["mean_CRS", "mean_R_final", "pct_reduction_vs_classical", "pct_diff_vs_ufmb",
                           "mean_ldf_active", "disc_correction_pct", "ampl_correction_pct",
                           "n_neutral", "n_disc", "n_ampl"]}
    for i in range(cfg.n_boot):
        b = resample(res, n_samples=len(res), replace=True, random_state=i)
        mr, mc = b["R_final"].mean(), b["Composite_Risk_Score"].mean()
        disc, ampl = b[b["LDF"] < 1.0], b[b["LDF"] > 1.0]
        act = b[b["LDF"] != 1.0]
        out["mean_CRS"].append(mc)
        out["mean_R_final"].append(mr)
        out["pct_reduction_vs_classical"].append((1 - mr / b["Cost (M USD)"].mean()) * 100)
        out["pct_diff_vs_ufmb"].append((mr - ufmb_mean) / ufmb_mean * 100)
        out["mean_ldf_active"].append(act["LDF"].mean() if len(act) else np.nan)
        out["n_neutral"].append(int((b["LDF"] == 1.0).sum()))
        out["n_disc"].append(len(disc))
        out["n_ampl"].append(len(ampl))
        out["disc_correction_pct"].append(((disc["R_final"] / disc["Composite_Risk_Score"] - 1) * 100).mean() if len(disc) else np.nan)
        out["ampl_correction_pct"].append(((ampl["R_final"] / ampl["Composite_Risk_Score"] - 1) * 100).mean() if len(ampl) else np.nan)
    dist = pd.DataFrame(out)
    rows = []
    for k in dist.columns:
        v = dist[k].dropna()
        rows.append({"metric": k, "mean": v.mean(), "ci95_low": np.percentile(v, 2.5),
                     "ci95_high": np.percentile(v, 97.5)})
    return dist, pd.DataFrame(rows)


def space_weather_dependence(df, res, seed=42):
    """Monotonic (Spearman) AND non-linear (mutual information) dependence of Ap / AE on the model outputs."""
    ae = df["AE_daily"].fillna(df["AE_daily"].median())
    rows = []
    targets = {"mu_fuzzy": res["mu_fuzzy"], "Composite_Risk_Score": res["Composite_Risk_Score"],
               "R_final": res["R_final"], "Cost (M USD)": res["Cost (M USD)"]}
    for var, x in (("Ap_daily", df["Ap_daily"]), ("AE_daily", ae)):
        for tname, t in targets.items():
            rho, p = spearmanr(x, t)
            mi = mutual_info_regression(x.to_numpy().reshape(-1, 1), t.to_numpy(), random_state=seed, n_neighbors=3)[0]
            rows.append({"covariate": var, "target": tname, "spearman_rho": rho, "spearman_p": p, "mutual_info": mi})
        y = LabelEncoder().fit_transform(df["Causes"])
        mi = mutual_info_classif(x.to_numpy().reshape(-1, 1), y, random_state=seed, n_neighbors=3)[0]
        rows.append({"covariate": var, "target": "Causes (class)", "spearman_rho": np.nan, "spearman_p": np.nan, "mutual_info": mi})
    return pd.DataFrame(rows)
