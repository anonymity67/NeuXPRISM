"""Goal A - failure-cause diagnosis.

Two classifiers are evaluated under the same leave-one-out protocol:
  1. NeuCube SNN : cost-including reservoir -> DeSNN state vectors -> SVM etc.
  2. Bayesian    : fleet posterior P(cause | phase), and geography-stratified (GIS-conditioned) variants.
"""
from __future__ import annotations
import warnings
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import LeaveOneOut
from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import LabelEncoder
from sklearn.svm import SVC

from .encoding import build_feature_matrix, rate_encode
from .reservoir import run_reservoir, activity_stats


# ------------------------------------------------------------------ NeuCube read-out
def _loocv(make_model, X, y):
    preds = np.empty(len(y), dtype=int)
    for tr, te in LeaveOneOut().split(X):
        m = make_model()
        m.fit(X[tr], y[tr])
        preds[te] = m.predict(X[te])
    return preds


def _loocv_top2(X, y, seed):
    hit = 0
    for tr, te in LeaveOneOut().split(X):
        m = SVC(kernel="rbf", C=1.0, probability=True, random_state=seed)
        with warnings.catch_warnings():          # sklearn>=1.9 deprecates probability=True; behaviour is unchanged
            warnings.simplefilter("ignore", FutureWarning)
            m.fit(X[tr], y[tr])
        proba = m.predict_proba(X[te])[0]
        top2 = m.classes_[np.argsort(proba)[-2:]]
        hit += int(y[te][0] in top2)
    return hit / len(y)


def neucube_diagnosis(df, cfg, seed=None, with_stats=True, drop_target=False):
    """Cost-including reservoir (10 inputs) + DeSNN + classifiers under LOOCV.

    drop_target=False reproduces the original notebook, in which 'Causes' (the label being predicted)
    is ALSO one of the reservoir inputs. drop_target=True removes it, giving a leakage-free estimate.
    """
    from neucube.sampler import DeSNN
    seed = cfg.seed if seed is None else seed
    feats = [f for f in cfg.features_with_cost if not (drop_target and f == "Causes")]
    cats = [c for c in cfg.categorical if c in feats]
    X, _ = build_feature_matrix(df, feats, cats, cfg.heritage_encoding, cfg.heritage_map)
    X_rate = rate_encode(X, cfg.T, seed)
    reservoir, activity = run_reservoir(X_rate, inputs=X.shape[1], cfg=cfg, seed=seed)
    states = DeSNN(**cfg.desnn).sample(activity).detach().cpu().numpy()
    y = LabelEncoder().fit_transform(df["Causes"].astype(str))

    models = {
        "SVM (rbf)": lambda: SVC(kernel="rbf", C=1.0),
        "SVM (linear)": lambda: SVC(kernel="linear", C=1.0),
        "Random Forest": lambda: RandomForestClassifier(n_estimators=100, random_state=42),
        "KNN (k=5)": lambda: KNeighborsClassifier(n_neighbors=5),
    }
    tag = " [Causes removed from input]" if drop_target else " [Causes in input, as original]"
    rows = [{"Method": f"NeuCube + {k}{tag}", "Top-1 (%)": float((_loocv(f, states, y) == y).mean() * 100)}
            for k, f in models.items()]
    top2 = _loocv_top2(states, y, seed) * 100
    out = {"table": pd.DataFrame(rows), "top1": rows[0]["Top-1 (%)"], "top2": top2,
           "majority_pct": float(np.bincount(y).max() / len(y) * 100)}
    if with_stats:
        out["stats"] = activity_stats(X_rate, activity)
    out["reservoir"], out["activity"] = reservoir, activity
    return out


def neucube_stability(df, cfg, runs=None, drop_target=False):
    """Repeat the whole NeuCube pipeline with new spike noise AND a new reservoir each time."""
    from neucube.sampler import DeSNN
    runs = cfg.stability_runs if runs is None else runs
    feats = [f for f in cfg.features_with_cost if not (drop_target and f == "Causes")]
    X, _ = build_feature_matrix(df, feats, [c for c in cfg.categorical if c in feats],
                                cfg.heritage_encoding, cfg.heritage_map)
    y = LabelEncoder().fit_transform(df["Causes"].astype(str))
    accs = []
    for r in range(runs):
        s = cfg.seed + 100 + r
        _, act = run_reservoir(rate_encode(X, cfg.T, s), X.shape[1], cfg, s)
        states = DeSNN().sample(act).detach().cpu().numpy()   # default DeSNN params, as in the notebook
        accs.append((_loocv(lambda: SVC(kernel="rbf", C=1.0), states, y) == y).mean() * 100)
    return pd.DataFrame({"run": range(1, runs + 1), "top1_pct": accs})


# ------------------------------------------------------------------ Bayesian diagnosis
def bayes_loocv(df, strata=None, alpha=0.0):
    """Leave-one-out Bayesian cause diagnosis.

    strata=None  -> fleet posterior   P(c | phase)                      (no geography)
    strata=[...] -> GIS-conditioned   P(c | phase, stratum) from the matching stratum, falling back to the
                    fleet posterior when the stratum has no rows with that phase.
    alpha        -> additive (Laplace) smoothing on the cause counts.
    Ties are broken by alphabetical class order (stable), so results are deterministic.
    """
    classes = sorted(df["Causes"].unique())
    top1 = top2 = 0
    for i in range(len(df)):
        te, tr = df.iloc[i], df.drop(df.index[i])
        pool = tr
        if strata:
            m = np.ones(len(tr), bool)
            for g in strata:
                m &= (tr[g] == te[g]).to_numpy()
            pool = tr[m]
        sp = pool[pool["Phase"] == te["Phase"]]
        if len(sp) == 0:
            sp = tr[tr["Phase"] == te["Phase"]]
        if len(sp) == 0:
            sp = tr
        p = np.array([((sp["Causes"] == c).sum() + alpha) for c in classes], float)
        p = p / p.sum()
        order = np.argsort(-p, kind="stable")
        top1 += classes[order[0]] == te["Causes"]
        top2 += te["Causes"] in [classes[k] for k in order[:2]]
    n = len(df)
    return top1 / n * 100, top2 / n * 100


def bayesian_diagnosis(df):
    variants = [("Bayesian fleet posterior P(c|phase)", None),
                ("Bayesian + latitude band", ["Lat_Band"]),
                ("Bayesian + coast category", ["Coast_Category"]),
                ("Bayesian + latitude band + coast", ["Lat_Band", "Coast_Category"]),
                ("Bayesian + spaceport", ["Spaceport"])]
    rows = []
    for name, strata in variants:
        if strata and any(s not in df.columns for s in strata):
            continue
        t1, t2 = bayes_loocv(df, strata)
        rows.append({"Method": name, "Top-1 (%)": t1, "Top-2 (%)": t2})
    return pd.DataFrame(rows)
