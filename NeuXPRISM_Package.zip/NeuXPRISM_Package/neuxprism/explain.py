"""SHAP attribution through a Random-Forest surrogate trained on the NeuXPRISM score."""
from __future__ import annotations
import numpy as np
import pandas as pd


def shap_importance(X_nocost, y, feature_names, cfg):
    import shap
    from sklearn.ensemble import RandomForestRegressor
    rf = RandomForestRegressor(**cfg.rf_surrogate).fit(X_nocost, y)
    sv = shap.TreeExplainer(rf).shap_values(X_nocost)
    imp = pd.DataFrame({"Feature": feature_names, "mean_abs_SHAP": np.abs(sv).mean(axis=0)}) \
        .sort_values("mean_abs_SHAP", ascending=False).reset_index(drop=True)
    return imp, float(rf.score(X_nocost, y)), sv
