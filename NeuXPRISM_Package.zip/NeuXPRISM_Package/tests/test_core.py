"""Fast checks that need no NeuCube:  python -m pytest tests   (or: python tests/test_core.py)"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import numpy as np, pandas as pd
from neuxprism.config import Config
from neuxprism import data, ldf, risk, goal_a, goal_c
from neuxprism.encoding import rate_encode

cfg = Config()
DF = data.load_dataset(cfg.data_path, cfg.sheet_name, verbose=False)


def test_dataset():
    assert len(DF) == 80 and DF["Datum"].is_monotonic_increasing


def test_ufmb_fleet_probabilities_derive_from_data():
    assert np.allclose(risk.fleet_phase_probabilities(DF, cfg), (0.2875, 0.6125))


def test_tier_edges():
    assert list(risk.assign_tier([9.99, 10, 29.99, 30, 59.99, 60], cfg)) == ["Low", "Medium", "Medium", "High", "High", "Critical"]


def test_ldf_matches_paper_split():
    c = ldf.compute_ldf(DF, cfg)
    assert (c["LDF_Category"] == "Neutral").sum() == 51 and (c["LDF_Category"] == "Discounted").sum() == 17
    assert (c["LDF_Category"] == "Amplified").sum() == 12
    assert abs(c["LDF"].min() - 0.711) < 1e-3 and abs(c["LDF"].max() - 1.378) < 1e-3


def test_ldf_formula_by_hand():  # GSLV Mk I / INSAT-4C style: CR=1, HI=2/3, FF=1/9 -> 1+.4-.2667-.0222
    comp = pd.DataFrame({"CR": [1.0], "HI": [2 / 3], "FF": [1 / 9]})
    assert abs(ldf.ldf_value(comp, .4, .4, .2).iloc[0] - 1.1111) < 1e-3


def test_rate_encoding_reproducible():
    X = np.random.default_rng(0).random((5, 3))
    assert (rate_encode(X, 50, 1) == rate_encode(X, 50, 1)).all() and rate_encode(X, 50, 1).shape == (5, 50, 3)


def test_bayes_fleet_baseline():
    assert goal_a.bayes_loocv(DF) == (58.75, 77.5)


def test_derived_markov_matches_shipped_csv():
    t = goal_c.derive_markov_weights(DF, cfg).set_index("Spaceport")
    ref = pd.read_csv(cfg.markov_path).set_index("Spaceport").reindex(t.index)
    assert len(t) == 19
    assert (t["P_Liftoff_Adjusted"] - ref["P_Liftoff_Adjusted"]).abs().max() < 0.002
    assert (t["P_Upper_Adjusted"] - ref["P_Upper_Adjusted"]).abs().max() < 0.002
    assert t[["W_Liftoff", "W_UpperStage"]].round(3).drop_duplicates().shape[0] == 8   # grouped, not 19 site-specific
    assert (t["P_Liftoff_Adjusted"] + t["P_Upper_Adjusted"] < 1).all()


if __name__ == "__main__":
    for k, f in list(globals().items()):
        if k.startswith("test_"):
            f(); print("ok", k)
