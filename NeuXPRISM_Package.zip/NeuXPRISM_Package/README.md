# NeuXPRISM: reproducible pipeline

Neuromorphic spatio-temporal pre-mission risk assessment with adaptive expected loss.
One command runs the whole model and writes every table and figure.

## 1. Set up (Windows / Anaconda)

```
conda create -n neuxprism python=3.11 -y
conda activate neuxprism
cd <this folder>
pip install -r requirements.txt
```

`requirements.txt` installs NeuCube-Py from a GitHub zip download (Git is not needed; internet is).
The old notebook pinned `scipy==1.11.4`. We did not need that, but if `import neucube`
fails with a scipy error, run `pip install scipy==1.11.4` (Python 3.11 or older).

## 2. Put the data in `data/`

| File | Status |
|---|---|
| `data/Main_Dataset_Fixed.xlsx` | included (repaired dataset, sheet `Master_Sheet`) |
| `data/Markov_Spatial_Weights_Corrected.csv` | included (your file). Optional: if absent, or with `--derive-markov`, the weights are computed from the dataset (see section 5, item 10) |

Or point to files anywhere: `--data path.xlsx --markov path.csv`.

## 3. Run

```
python run_pipeline.py                  # full run (about 25-30 min, mostly repeated NeuCube runs)
python run_pipeline.py --derive-markov  # compute the spatial weights from the dataset instead of reading the CSV
python run_pipeline.py --quick          # about 3 min: skips stability runs, bootstrap, multi-seed
python run_pipeline.py --multi-seed 5   # also repeats Goals B/C/LDF with 5 different reservoirs
python run_pipeline.py --heritage-encoding ordinal   # New<Low<Medium<High instead of alphabetical
python tests/test_core.py               # 8 quick sanity checks (no NeuCube needed)
```

Everything lands in `results/`. The last step prints a **paper-vs-this-run table**
(`Paper_Reference_Check.csv`).

## 4. What the model does and where it lives

| Paper element | Code | Main outputs (`results/`) |
|---|---|---|
| Data load + validation (site-attribute consistency, 80 rows) | `neuxprism/data.py` | |
| Rate encoding T=100, min-max, Time_Position | `encoding.py` | |
| NeuCube 10x10x10 reservoir, STDP | `reservoir.py` | `Reservoir_Activity_Stats.csv`, `Encoding_Density_Diagnostics.csv` |
| **Goal A** cause diagnosis (NeuCube+DeSNN, SVM/RF/KNN, Top-2, stability; Bayesian) | `goal_a.py` | `GoalA_Diagnosis.csv`, `GoalA_NeuCube_Stability_*.csv` |
| **Goal B** mu_fuzzy from a cost-free reservoir, EL_fuzzy | `goal_b.py` | `NeuXPRISM_Full_Results.csv` |
| **Goal C** spatial Markov, P_contextual, EL_markov | `goal_c.py` | same |
| **LDF** (walk-forward per Company+Vehicle), sensitivity, walk-forward tables | `ldf.py` | `LDF_Sensitivity.csv`, `WalkForward_*.csv` |
| Composite Risk Score, R_final, tiers, Classical/UFMB comparison, tier confusion | `risk.py`, `pipeline.py` | `EL_Comparison.csv`, `Tier_Confusion_Matrix.csv` |
| SHAP (Random-Forest surrogate) | `explain.py` | `SHAP_Importance_*.csv` |
| LOOCV EL comparison, Linear/XGBoost baselines, bootstrap, Ap/AE Spearman + mutual information | `evaluation.py` | `LOOCV_EL_Comparison.csv`, `Baseline_Comparison_EL.csv`, `NeuXPRISM_Bootstrap_*.csv`, `SpaceWeather_Dependence.csv` |
| Figures 6, 7, 8, 9, 11, bootstrap raincloud, Evolution figure | `figures.py` | `*.png` |

Formulas: `CRS = (EL_fuzzy + EL_markov)/2`; `R_final = CRS x LDF`;
`LDF = clip(1 + 0.4 CR - 0.4 HI - 0.2 FF, 0.1, 1.5)`; tiers at $10M / $30M / $60M.
All settings, including the paper reference numbers, are in `neuxprism/config.py`.

## 5. Changes from the original notebook (read this before comparing numbers)

1. **Seeds are fixed** (`--seed`, default 42). The reservoir wiring, STDP and rate-coding noise
   used to be unseeded, so every run differed. The same seed now gives identical results.
   Different seeds give different mu_fuzzy and therefore different R_final; `--multi-seed N` measures that spread.
2. **One chronological sort.** The notebook fed an *unsorted* feature matrix to the Goal A reservoir but *date-sorted*
   labels to the classifier. That only works if the file is already in date order, which `Main_Dataset_Fixed.xlsx` is not.
   The loader now sorts once and everything downstream uses that order.
3. **Goal A leakage is made visible.** In the notebook `Causes` is one of the reservoir inputs while also being the label.
   The package reports both the original setting and a leakage-free one (`Causes` removed).
4. **Bayesian Goal A is now computed**, not hard-coded. The 58.75% / 77.50% figures are reproduced by the
   *fleet* posterior P(cause | phase). Geography-stratified versions are listed beside it.
5. **UFMB fleet probabilities** (0.2875 / 0.6125) are computed from the corpus (23/80, 49/80), not typed in.
6. The **tier confusion matrix** uses the final (LDF-inclusive) R_final; the notebook used the pre-LDF score.
7. SHAP is reported for both the final R_final and the pre-LDF Composite Risk Score.
8. Output column names follow the paper: `Composite_Risk_Score` (pre-LDF) and `R_final` (LDF-inclusive).
   Older CSVs called these `R_final` and `R_learned`; do not mix the two conventions.
9. The Heritage Category label encoding is alphabetical (High=0, Low=1, Medium=2, New=3) to match the original
   numbers. It is not ordinal; use `--heritage-encoding ordinal` if you want a meaningful scale.

10. **The spatial Markov weights are not the per-site formula of Eq. 4-6.** Applying that formula literally (site failures /
    site launches over the fleet rate) gives unusable values for small sites (weights up to ~300, or exactly 0). The shipped
    CSV, and `--derive-markov`, use a different method: for each latitude band and each 3-level coast category
    (Coastal < 20 km, Near-Inland < 500 km, Deep-Inland) take P(phase | group) / P(phase) from failure counts, multiply the two
    factors, and renormalise so the phase probabilities sum to 1 (other phases = 0.1). Sites in the same band and category share
    weights, so there are 8 distinct pairs for 19 spaceports. The derived values match the CSV to within 0.003 (tested).
    The weights and the fleet baselines are computed from the same 80 failures they are then applied to (in-sample).
11. The four garbled `Detail` strings in the dataset were repaired (e.g. `Foton-M nÂ°1` -> `Foton-M n°1`).
12. The paper-vs-run table compares the paper's 48.1% spike density with the **input** density (fraction of 1s in the rate-coded
    input); the reservoir density is reported separately. The paper does not define which quantity 48.1% is.

## 6. Known limitations

- The LDF heritage term is not cumulative: it compares only with the latest prior failure, so a discount disappears if heritage stays
  unchanged (visible for Kairos). Changing this would alter the headline numbers, so it is left as in the paper.
- The LOOCV EL comparison scores estimates against mission cost as a proxy for loss; treat it as descriptive.
- `Causes` and `Phase` are inputs to the cost-free reservoir (Goal B). That is the original design, but they
  are diagnosed quantities, not known before a mission.
- Run time depends on CPU; NeuCube-Py is not GPU-accelerated here.
